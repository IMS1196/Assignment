package org.example;

public class Program {
    public static void main(String[] args){
        char[] c = {'a', 'b', 'c', 'd', 'e'};
        for (int i = 0, l = c.length; i < l; ++i) {
            char res = (char) (c[i] - 32);
            System.out.println(res);
        }

    }
}